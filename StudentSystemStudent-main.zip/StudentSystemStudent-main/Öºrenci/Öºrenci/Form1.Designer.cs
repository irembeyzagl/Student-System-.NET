﻿namespace Öğrenci
{
    partial class Öğrencigirişsayfası
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Öğrencigirişsayfası));
            this.numaratxt = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.nolblb = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.şifrelbl = new System.Windows.Forms.Label();
            this.şifretxt = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // numaratxt
            // 
            this.numaratxt.Location = new System.Drawing.Point(297, 162);
            this.numaratxt.Name = "numaratxt";
            this.numaratxt.Size = new System.Drawing.Size(289, 22);
            this.numaratxt.TabIndex = 11;
            this.numaratxt.TextChanged += new System.EventHandler(this.numaratxt_TextChanged);
            // 
            // button1
            // 
            this.button1.FlatAppearance.BorderSize = 4;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button1.Location = new System.Drawing.Point(297, 324);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(165, 74);
            this.button1.TabIndex = 9;
            this.button1.Text = "GİRİŞ";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            this.button1.MouseHover += new System.EventHandler(this.button1_MouseHover);
            // 
            // nolblb
            // 
            this.nolblb.AutoSize = true;
            this.nolblb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.nolblb.Location = new System.Drawing.Point(162, 159);
            this.nolblb.Name = "nolblb";
            this.nolblb.Size = new System.Drawing.Size(128, 25);
            this.nolblb.TabIndex = 8;
            this.nolblb.Text = "Öğrenci No:";
            this.nolblb.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(232, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(302, 32);
            this.label1.TabIndex = 6;
            this.label1.Text = "Öğrenci Giriş Sayfası";
            // 
            // şifrelbl
            // 
            this.şifrelbl.AutoSize = true;
            this.şifrelbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.şifrelbl.Location = new System.Drawing.Point(164, 221);
            this.şifrelbl.Name = "şifrelbl";
            this.şifrelbl.Size = new System.Drawing.Size(64, 25);
            this.şifrelbl.TabIndex = 12;
            this.şifrelbl.Text = "Şifre:";
            this.şifrelbl.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // şifretxt
            // 
            this.şifretxt.Location = new System.Drawing.Point(297, 234);
            this.şifretxt.Name = "şifretxt";
            this.şifretxt.Size = new System.Drawing.Size(289, 22);
            this.şifretxt.TabIndex = 13;
            this.şifretxt.TextChanged += new System.EventHandler(this.şifretxt_TextChanged);
            // 
            // Öğrencigirişsayfası
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MistyRose;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.şifretxt);
            this.Controls.Add(this.şifrelbl);
            this.Controls.Add(this.numaratxt);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.nolblb);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Öğrencigirişsayfası";
            this.Text = "Öğrenci Giriş Sayfası";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox numaratxt;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label nolblb;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label şifrelbl;
        private System.Windows.Forms.TextBox şifretxt;
    }
}

