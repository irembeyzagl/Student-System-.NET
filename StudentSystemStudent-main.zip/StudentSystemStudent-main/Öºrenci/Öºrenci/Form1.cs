﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Öğrenci
{
    public partial class Öğrencigirişsayfası : Form
    {
        SqlConnection conn;
        SqlDataReader rd;
        SqlCommand com;
        public Öğrencigirişsayfası()
        {
            InitializeComponent();
        }
        public static string göderilecek_değer;
        private void button1_Click(object sender, EventArgs e)
        {
            
            conn = new SqlConnection("Data Source=DESKTOP-3DNAMQC;Initial Catalog=adonet;Integrated Security=True");
            com = new SqlCommand();
            conn.Open();
            com.Connection = conn;
            com.CommandText = "Select öğrenci_no From öğrenci Where öğrenci_no='" + numaratxt.Text + "' AND password='"+şifretxt.Text+"'";
            ; rd = com.ExecuteReader();
            if (rd.Read())
            {
                MessageBox.Show("Giriş Başarılı");
                göderilecek_değer = numaratxt.Text;
                Form2 form2 = new Form2();
                form2.Show();  // form2 göster diyoruz
                this.Hide();


            }
            else
            {
                MessageBox.Show("Hatalı email ve ya şifre");
            }
            conn.Close();
        }

        private void button1_MouseHover(object sender, EventArgs e)
        {
            button1.BackColor = Color.Black;
            button1.ForeColor = Color.White;
        }

        private void numaratxt_TextChanged(object sender, EventArgs e)
        {
            numaratxt.ForeColor = Color.DarkBlue;
        }

        private void şifretxt_TextChanged(object sender, EventArgs e)
        {
            şifretxt.ForeColor = Color.DarkBlue;
            şifretxt.PasswordChar = '*';
        }
    }
}
