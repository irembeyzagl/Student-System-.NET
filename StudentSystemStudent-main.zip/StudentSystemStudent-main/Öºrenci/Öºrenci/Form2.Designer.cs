﻿namespace Öğrenci
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.CustomLabel customLabel1 = new System.Windows.Forms.DataVisualization.Charting.CustomLabel();
            System.Windows.Forms.DataVisualization.Charting.CustomLabel customLabel2 = new System.Windows.Forms.DataVisualization.Charting.CustomLabel();
            System.Windows.Forms.DataVisualization.Charting.CustomLabel customLabel3 = new System.Windows.Forms.DataVisualization.Charting.CustomLabel();
            System.Windows.Forms.DataVisualization.Charting.CustomLabel customLabel4 = new System.Windows.Forms.DataVisualization.Charting.CustomLabel();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button2 = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.görüntülebtn = new System.Windows.Forms.Button();
            this.listView1 = new System.Windows.Forms.ListView();
            this.DersAdı = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.DersGünü = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.DersSaati = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Derslik = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.button3 = new System.Windows.Forms.Button();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.sonuçbtn = new System.Windows.Forms.Button();
            this.listView2 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Vize = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.button4 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.ders_kayıt = new System.Windows.Forms.Label();
            this.gün_saat = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.ders_adları = new System.Windows.Forms.ComboBox();
            this.ders_adı = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.button6 = new System.Windows.Forms.Button();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.tabControl1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Location = new System.Drawing.Point(4, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(794, 447);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.button2);
            this.tabPage2.Controls.Add(this.listBox1);
            this.tabPage2.Controls.Add(this.görüntülebtn);
            this.tabPage2.Controls.Add(this.listView1);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(786, 418);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Ders Programı";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button2.Location = new System.Drawing.Point(713, 367);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(67, 45);
            this.button2.TabIndex = 4;
            this.button2.Text = "Çıkış";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // listBox1
            // 
            this.listBox1.BackColor = System.Drawing.Color.MistyRose;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Location = new System.Drawing.Point(17, 41);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(646, 356);
            this.listBox1.TabIndex = 3;
            // 
            // görüntülebtn
            // 
            this.görüntülebtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.görüntülebtn.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.görüntülebtn.Location = new System.Drawing.Point(666, 228);
            this.görüntülebtn.Name = "görüntülebtn";
            this.görüntülebtn.Size = new System.Drawing.Size(114, 29);
            this.görüntülebtn.TabIndex = 2;
            this.görüntülebtn.Text = "Görüntüle";
            this.görüntülebtn.UseVisualStyleBackColor = true;
            this.görüntülebtn.Click += new System.EventHandler(this.görüntülebtn_Click);
            this.görüntülebtn.MouseHover += new System.EventHandler(this.görüntülebtn_MouseHover);
            // 
            // listView1
            // 
            this.listView1.BackColor = System.Drawing.Color.MistyRose;
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.DersAdı,
            this.DersGünü,
            this.DersSaati,
            this.Derslik});
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(6, 7);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(779, 406);
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            // 
            // DersAdı
            // 
            this.DersAdı.Text = "Ders Adı";
            this.DersAdı.Width = 191;
            // 
            // DersGünü
            // 
            this.DersGünü.Text = "Ders Günü";
            this.DersGünü.Width = 173;
            // 
            // DersSaati
            // 
            this.DersSaati.Text = "Ders Saati";
            this.DersSaati.Width = 153;
            // 
            // Derslik
            // 
            this.Derslik.Text = "Derslik";
            this.Derslik.Width = 118;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.MistyRose;
            this.tabPage3.Controls.Add(this.button3);
            this.tabPage3.Controls.Add(this.listBox2);
            this.tabPage3.Controls.Add(this.sonuçbtn);
            this.tabPage3.Controls.Add(this.listView2);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(786, 418);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Sınav Sonuçları";
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button3.Location = new System.Drawing.Point(713, 366);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(67, 45);
            this.button3.TabIndex = 5;
            this.button3.Text = "Çıkış";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // listBox2
            // 
            this.listBox2.BackColor = System.Drawing.Color.MistyRose;
            this.listBox2.FormattingEnabled = true;
            this.listBox2.ItemHeight = 16;
            this.listBox2.Location = new System.Drawing.Point(11, 39);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(634, 372);
            this.listBox2.TabIndex = 3;
            // 
            // sonuçbtn
            // 
            this.sonuçbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.sonuçbtn.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.sonuçbtn.Location = new System.Drawing.Point(645, 269);
            this.sonuçbtn.Name = "sonuçbtn";
            this.sonuçbtn.Size = new System.Drawing.Size(141, 44);
            this.sonuçbtn.TabIndex = 2;
            this.sonuçbtn.Text = "Görüntüle";
            this.sonuçbtn.UseVisualStyleBackColor = true;
            this.sonuçbtn.Click += new System.EventHandler(this.sonuçbtn_Click);
            this.sonuçbtn.MouseHover += new System.EventHandler(this.sonuçbtn_MouseHover);
            // 
            // listView2
            // 
            this.listView2.BackColor = System.Drawing.Color.MistyRose;
            this.listView2.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.Vize,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader2});
            this.listView2.HideSelection = false;
            this.listView2.Location = new System.Drawing.Point(4, 6);
            this.listView2.Name = "listView2";
            this.listView2.Size = new System.Drawing.Size(645, 406);
            this.listView2.TabIndex = 1;
            this.listView2.UseCompatibleStateImageBehavior = false;
            this.listView2.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Ders Adı";
            this.columnHeader1.Width = 156;
            // 
            // Vize
            // 
            this.Vize.Text = "Vize";
            this.Vize.Width = 133;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Final";
            this.columnHeader3.Width = 153;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Bütünleme";
            this.columnHeader4.Width = 118;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Harf Notu";
            this.columnHeader2.Width = 138;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.MistyRose;
            this.tabPage1.Controls.Add(this.button4);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.ders_kayıt);
            this.tabPage1.Controls.Add(this.gün_saat);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.ders_adları);
            this.tabPage1.Controls.Add(this.ders_adı);
            this.tabPage1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(786, 418);
            this.tabPage1.TabIndex = 3;
            this.tabPage1.Text = "Ders Kaydı";
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button4.Location = new System.Drawing.Point(701, 367);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(67, 45);
            this.button4.TabIndex = 6;
            this.button4.Text = "Çıkış";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button1.Location = new System.Drawing.Point(220, 311);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(203, 69);
            this.button1.TabIndex = 5;
            this.button1.Text = "KAYDET";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            this.button1.MouseHover += new System.EventHandler(this.button1_MouseHover);
            // 
            // ders_kayıt
            // 
            this.ders_kayıt.AutoSize = true;
            this.ders_kayıt.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.ders_kayıt.Location = new System.Drawing.Point(203, 13);
            this.ders_kayıt.Name = "ders_kayıt";
            this.ders_kayıt.Size = new System.Drawing.Size(338, 32);
            this.ders_kayıt.TabIndex = 4;
            this.ders_kayıt.Text = "ÖĞRENCİ DERS KAYDI";
            // 
            // gün_saat
            // 
            this.gün_saat.FormattingEnabled = true;
            this.gün_saat.Location = new System.Drawing.Point(255, 233);
            this.gün_saat.Name = "gün_saat";
            this.gün_saat.Size = new System.Drawing.Size(222, 24);
            this.gün_saat.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(73, 233);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(164, 22);
            this.label1.TabIndex = 2;
            this.label1.Text = "Gün-Saat-Derslik";
            // 
            // ders_adları
            // 
            this.ders_adları.FormattingEnabled = true;
            this.ders_adları.Items.AddRange(new object[] {
            "Calculus1",
            "Calculus2",
            "Fizik1",
            "Fİzik2",
            "Lİneear Cebir",
            "Diferansiyel Denklemler",
            "Mühendisliğe Giriş ",
            "Algoritma ve Programlama",
            "Nesneye Yönelik Programlama",
            "Web "});
            this.ders_adları.Location = new System.Drawing.Point(255, 132);
            this.ders_adları.Name = "ders_adları";
            this.ders_adları.Size = new System.Drawing.Size(222, 24);
            this.ders_adları.TabIndex = 1;
            this.ders_adları.SelectedIndexChanged += new System.EventHandler(this.ders_adları_SelectedIndexChanged);
            // 
            // ders_adı
            // 
            this.ders_adı.AutoSize = true;
            this.ders_adı.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.ders_adı.Location = new System.Drawing.Point(73, 132);
            this.ders_adı.Name = "ders_adı";
            this.ders_adı.Size = new System.Drawing.Size(93, 22);
            this.ders_adı.TabIndex = 0;
            this.ders_adı.Text = "Ders Adı:";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.button6);
            this.tabPage4.Controls.Add(this.chart1);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(786, 418);
            this.tabPage4.TabIndex = 4;
            this.tabPage4.Text = "Gano";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button6.Location = new System.Drawing.Point(713, 355);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(67, 45);
            this.button6.TabIndex = 5;
            this.button6.Text = "Çıkış";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // chart1
            // 
            this.chart1.BackColor = System.Drawing.Color.MistyRose;
            customLabel1.Text = "1.sınıf";
            customLabel2.Text = "2.sınıf";
            customLabel3.Text = "3.sınıf";
            customLabel4.Text = "4.sınıf";
            chartArea1.AxisX.CustomLabels.Add(customLabel1);
            chartArea1.AxisX.CustomLabels.Add(customLabel2);
            chartArea1.AxisX.CustomLabels.Add(customLabel3);
            chartArea1.AxisX.CustomLabels.Add(customLabel4);
            chartArea1.AxisX.Title = "Sınıflar";
            chartArea1.BackColor = System.Drawing.Color.MistyRose;
            chartArea1.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chart1.Legends.Add(legend1);
            this.chart1.Location = new System.Drawing.Point(6, 6);
            this.chart1.Name = "chart1";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "GANO";
            this.chart1.Series.Add(series1);
            this.chart1.Size = new System.Drawing.Size(774, 409);
            this.chart1.TabIndex = 3;
            this.chart1.Text = "chart1";
            this.chart1.Click += new System.EventHandler(this.chart1_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.IndianRed;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.ForeColor = System.Drawing.SystemColors.Control;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form2";
            this.Text = "ÖğrenciSistemi";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.ColumnHeader DersAdı;
        private System.Windows.Forms.ColumnHeader DersGünü;
        private System.Windows.Forms.ColumnHeader DersSaati;
        private System.Windows.Forms.ColumnHeader Derslik;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label ders_adı;
        private System.Windows.Forms.ComboBox ders_adları;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox gün_saat;
        private System.Windows.Forms.Label ders_kayıt;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button sonuçbtn;
        private System.Windows.Forms.ListView listView2;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader Vize;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.Button görüntülebtn;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.Button button6;
    }
}