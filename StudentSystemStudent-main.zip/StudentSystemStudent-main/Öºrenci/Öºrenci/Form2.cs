﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Reflection.Emit;
using System.Windows.Forms.DataVisualization.Charting;
namespace Öğrenci
{
    public partial class Form2 : Form
    {
        
        public Form2()
        {
            InitializeComponent();
        }

       
        private void listView1_SelectedIndexChanged(object sender, EventArgs e)  {
        }

            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-3DNAMQC;Initial Catalog=adonet;Integrated Security=True");
            string numara = Öğrencigirişsayfası.göderilecek_değer;
            private void görüntülebtn_Click(object sender, EventArgs e)
            {
                listBox1.Items.Clear();
                conn.Open();
                SqlCommand cmd = new SqlCommand("Select ders_adı,ders_kodu,ders_günü,ders_saati,derslik from öğrenci_ders_programı inner " +
                    "join öğrenci on öğrenci.ders_programı_id=öğrenci_ders_programı.id where öğrenci.öğrenci_no='" + numara + "'", conn);
                SqlDataReader rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    listBox1.Items.Add(rdr[0] + "               " + rdr[1] + "                " + rdr[2] + "                " + rdr[3] + "                  " + rdr[4]);
                }
                conn.Close();
            }

        private void ders_adları_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ders_adları.Text == "Calculus1")
            {
                gün_saat.Items.Clear();
                gün_saat.Items.Add("Pazartesi 10.30 \n Perşembe 13.30");
                gün_saat.Items.Add("Salı 08.30 \n Çarşamba 15.30 - Ma313");

            }

            if (ders_adları.Text == "Calculus2")
            {
                gün_saat.Items.Clear();
                gün_saat.Items.Add("Salı 08.30 \n Çarşamba 15.30 -MA112");
                gün_saat.Items.Add("Cuma 15.30  \n Perşembe 10.30 - MA113");
            }
            if (ders_adları.Text == "Fizik1")
            {
                gün_saat.Items.Clear();
                gün_saat.Items.Add("Pazartesi 13.30 \n Salı 13.30 MA116");

            }

            if (ders_adları.Text == "Fİzik2")
            {
                gün_saat.Items.Clear();
                gün_saat.Items.Add("Cuma 10.30 \n Perşembe 15.30 MA108");
                gün_saat.Items.Add("Pazartesi 13.30 \n Salı 13.30 - MA 206");
            }

            if (ders_adları.Text == "Lİneear Cebir")
            {
                gün_saat.Items.Clear();
                gün_saat.Items.Add("Salı 13.30 \n Çarşamba 13.30 - MA106");

            }
            if (ders_adları.Text == "Diferansiyel Denklemler")
            {
                gün_saat.Items.Clear();
                gün_saat.Items.Add("Pazartesi 08.30 \n Salı 08.30 - MA104");

            }
            if (ders_adları.Text == "Nesneye Yönelik Programlama")
            {
                gün_saat.Items.Clear();
                gün_saat.Items.Add("Cuma 15.30  \n Perşembe 10.30 - MA113");

            }

            if (ders_adları.Text == "Mühendisliğe Giriş")
            {
                gün_saat.Items.Clear();
                gün_saat.Items.Add("Salı 08.30 \n Çarşamba 15.30 - Ma313");

            }
            if (ders_adları.Text == "Algoritma ve Programlama - MA212")
            {
                gün_saat.Items.Clear();
                gün_saat.Items.Add("Pazartesi 13.30 \n Salı 13.30");

            }
            if (ders_adları.Text == "Web")
            {
                gün_saat.Items.Clear();
                gün_saat.Items.Add("Pazartesi 13.30 \n Salı 13.30 - MA 206");

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection();
            conn = new SqlConnection("Data Source=DESKTOP-3DNAMQC;Initial Catalog=adonet;Integrated Security=True");
            conn.Open();
            string ders = ders_adları.Text;
            string gün_saat_derslik = gün_saat.Text;
           


            string kayit = "Insert INTO ders (ders_adı,gün_saat_derslik) VALUES (@ders, @gün_saat_derslik)";



            SqlCommand cmd = new SqlCommand(kayit, conn);
            cmd.Parameters.AddWithValue("@ders", ders_adları.Text);
            cmd.Parameters.AddWithValue("@gün_saat_derslik", gün_saat.Text);
            
            cmd.ExecuteNonQuery();

            conn.Close();
            
           MessageBox.Show("Ders Başarıyla Kaydedildi");
        }

        private void sonuçbtn_Click(object sender, EventArgs e)
        {

            listBox2.Items.Clear();
            conn.Open();
            SqlCommand cmd2 = new SqlCommand(" Select ders.ders_adı,vize,final,bütünleme,harf_notu from sınav_sonuçları "+
                "inner join ders on ders.id = sınav_sonuçları.ders_id"+
                " inner join öğrenci on öğrenci.id = sınav_sonuçları.öğrenci_id where öğrenci.öğrenci_no ='" + numara + "'", conn);
            
            SqlDataReader rdr2 = cmd2.ExecuteReader();

            while (rdr2.Read())
            {
                listBox2.Items.Add(rdr2[0] +"           "+ rdr2[1] + "          " + rdr2[2] + "           " + rdr2[3] + "           " + rdr2[4]);
                
            }
           
            conn.Close();
        }

        private void görüntülebtn_MouseHover(object sender, EventArgs e)
        {
            görüntülebtn.BackColor = Color.Black;
            görüntülebtn.ForeColor = Color.White;
        }

        private void sonuçbtn_MouseHover(object sender, EventArgs e)
        {
            sonuçbtn.BackColor = Color.Black;
            sonuçbtn.ForeColor = Color.White;
        }

        private void button1_MouseHover(object sender, EventArgs e)
        {

            button1.BackColor = Color.Black;
            button1.ForeColor = Color.White;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.GetCurrentProcess().Kill();
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {

            System.Diagnostics.Process.GetCurrentProcess().Kill();
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {

            System.Diagnostics.Process.GetCurrentProcess().Kill();
            Application.Exit();
        }

        private void button5_Click(object sender, EventArgs e)
        {
           


        }

        private void chart1_Click(object sender, EventArgs e)
        {
            





        }

        private void button6_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.GetCurrentProcess().Kill();
            Application.Exit();

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection();
            conn = new SqlConnection("Data Source=DESKTOP-3DNAMQC;Initial Catalog=adonet;Integrated Security=True");
            conn.Open();
            SqlCommand cmd2 = new SqlCommand("SELECT öğrenci.sınıf,sınav_sonuçları.ortalama FROM öğrenci INNER JOIN sınav_sonuçları ON öğrenci.id = sınav_sonuçları.öğrenci_id", conn);
            SqlDataReader rdr = cmd2.ExecuteReader();
            while (rdr.Read())
            {
                
                    chart1.Series["GANO"].Points.AddXY(rdr[0].ToString(), rdr[1].ToString());
                chart1.Series["GANO"].AxisLabel = "Sınıf";
                
            }

            conn.Close();
        }
    }
}
