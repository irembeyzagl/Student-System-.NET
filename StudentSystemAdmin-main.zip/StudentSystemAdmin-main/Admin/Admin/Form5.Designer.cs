﻿namespace Admin
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form5));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.emailtxt = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.görüntülebtn = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.harfnotutxt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.derskodutxt = new System.Windows.Forms.TextBox();
            this.derskodulbl = new System.Windows.Forms.Label();
            this.notxt = new System.Windows.Forms.TextBox();
            this.öğrenciid = new System.Windows.Forms.Label();
            this.kaydetbtn = new System.Windows.Forms.Button();
            this.büttxt = new System.Windows.Forms.TextBox();
            this.finaltxt = new System.Windows.Forms.TextBox();
            this.vizetxt = new System.Windows.Forms.TextBox();
            this.bütünleme = new System.Windows.Forms.Label();
            this.finallbl = new System.Windows.Forms.Label();
            this.vizelbl = new System.Windows.Forms.Label();
            this.notlbl = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(5, 10);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(791, 431);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.MistyRose;
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.emailtxt);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.görüntülebtn);
            this.tabPage1.Controls.Add(this.listBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(783, 402);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Ders Programı";
            // 
            // emailtxt
            // 
            this.emailtxt.Location = new System.Drawing.Point(649, 198);
            this.emailtxt.Name = "emailtxt";
            this.emailtxt.Size = new System.Drawing.Size(125, 22);
            this.emailtxt.TabIndex = 3;
            this.emailtxt.TextChanged += new System.EventHandler(this.emailtxt_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(672, 141);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = "Email:";
            // 
            // görüntülebtn
            // 
            this.görüntülebtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.görüntülebtn.Location = new System.Drawing.Point(648, 363);
            this.görüntülebtn.Name = "görüntülebtn";
            this.görüntülebtn.Size = new System.Drawing.Size(132, 33);
            this.görüntülebtn.TabIndex = 1;
            this.görüntülebtn.Text = "Görüntüle";
            this.görüntülebtn.UseVisualStyleBackColor = true;
            this.görüntülebtn.Click += new System.EventHandler(this.görüntülebtn_Click);
            this.görüntülebtn.MouseHover += new System.EventHandler(this.görüntülebtn_MouseHover);
            // 
            // listBox1
            // 
            this.listBox1.BackColor = System.Drawing.Color.MistyRose;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Location = new System.Drawing.Point(6, 7);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(637, 356);
            this.listBox1.TabIndex = 0;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.MistyRose;
            this.tabPage2.Controls.Add(this.button2);
            this.tabPage2.Controls.Add(this.harfnotutxt);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.derskodutxt);
            this.tabPage2.Controls.Add(this.derskodulbl);
            this.tabPage2.Controls.Add(this.notxt);
            this.tabPage2.Controls.Add(this.öğrenciid);
            this.tabPage2.Controls.Add(this.kaydetbtn);
            this.tabPage2.Controls.Add(this.büttxt);
            this.tabPage2.Controls.Add(this.finaltxt);
            this.tabPage2.Controls.Add(this.vizetxt);
            this.tabPage2.Controls.Add(this.bütünleme);
            this.tabPage2.Controls.Add(this.finallbl);
            this.tabPage2.Controls.Add(this.vizelbl);
            this.tabPage2.Controls.Add(this.notlbl);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(783, 402);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Not Sistemi";
            // 
            // harfnotutxt
            // 
            this.harfnotutxt.Location = new System.Drawing.Point(199, 377);
            this.harfnotutxt.Name = "harfnotutxt";
            this.harfnotutxt.Size = new System.Drawing.Size(200, 22);
            this.harfnotutxt.TabIndex = 14;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS Reference Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(59, 377);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 22);
            this.label1.TabIndex = 13;
            this.label1.Text = "Harf Notu:";
            // 
            // derskodutxt
            // 
            this.derskodutxt.Location = new System.Drawing.Point(199, 175);
            this.derskodutxt.Name = "derskodutxt";
            this.derskodutxt.Size = new System.Drawing.Size(199, 22);
            this.derskodutxt.TabIndex = 12;
            // 
            // derskodulbl
            // 
            this.derskodulbl.AutoSize = true;
            this.derskodulbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.derskodulbl.Location = new System.Drawing.Point(58, 171);
            this.derskodulbl.Name = "derskodulbl";
            this.derskodulbl.Size = new System.Drawing.Size(121, 25);
            this.derskodulbl.TabIndex = 11;
            this.derskodulbl.Text = "Ders Kodu:";
            // 
            // notxt
            // 
            this.notxt.Location = new System.Drawing.Point(198, 125);
            this.notxt.Name = "notxt";
            this.notxt.Size = new System.Drawing.Size(201, 22);
            this.notxt.TabIndex = 10;
            this.notxt.TextChanged += new System.EventHandler(this.notxt_TextChanged);
            // 
            // öğrenciid
            // 
            this.öğrenciid.AutoSize = true;
            this.öğrenciid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.öğrenciid.Location = new System.Drawing.Point(58, 124);
            this.öğrenciid.Name = "öğrenciid";
            this.öğrenciid.Size = new System.Drawing.Size(128, 25);
            this.öğrenciid.TabIndex = 9;
            this.öğrenciid.Text = "Öğrenci No:";
            // 
            // kaydetbtn
            // 
            this.kaydetbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.kaydetbtn.Location = new System.Drawing.Point(559, 309);
            this.kaydetbtn.Name = "kaydetbtn";
            this.kaydetbtn.Size = new System.Drawing.Size(173, 80);
            this.kaydetbtn.TabIndex = 8;
            this.kaydetbtn.Text = "Kaydet";
            this.kaydetbtn.UseVisualStyleBackColor = true;
            this.kaydetbtn.Click += new System.EventHandler(this.kaydetbtn_Click_1);
            // 
            // büttxt
            // 
            this.büttxt.Location = new System.Drawing.Point(198, 338);
            this.büttxt.Name = "büttxt";
            this.büttxt.Size = new System.Drawing.Size(201, 22);
            this.büttxt.TabIndex = 7;
            // 
            // finaltxt
            // 
            this.finaltxt.Location = new System.Drawing.Point(198, 280);
            this.finaltxt.Name = "finaltxt";
            this.finaltxt.Size = new System.Drawing.Size(201, 22);
            this.finaltxt.TabIndex = 6;
            // 
            // vizetxt
            // 
            this.vizetxt.Location = new System.Drawing.Point(197, 226);
            this.vizetxt.Name = "vizetxt";
            this.vizetxt.Size = new System.Drawing.Size(202, 22);
            this.vizetxt.TabIndex = 5;
            this.vizetxt.TextChanged += new System.EventHandler(this.vizetxt_TextChanged_1);
            // 
            // bütünleme
            // 
            this.bütünleme.AutoSize = true;
            this.bütünleme.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.bütünleme.Location = new System.Drawing.Point(58, 334);
            this.bütünleme.Name = "bütünleme";
            this.bütünleme.Size = new System.Drawing.Size(121, 25);
            this.bütünleme.TabIndex = 4;
            this.bütünleme.Text = "Bütünleme:";
            // 
            // finallbl
            // 
            this.finallbl.AutoSize = true;
            this.finallbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.finallbl.Location = new System.Drawing.Point(84, 280);
            this.finallbl.Name = "finallbl";
            this.finallbl.Size = new System.Drawing.Size(66, 25);
            this.finallbl.TabIndex = 3;
            this.finallbl.Text = "Final:";
            // 
            // vizelbl
            // 
            this.vizelbl.AutoSize = true;
            this.vizelbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.vizelbl.Location = new System.Drawing.Point(84, 226);
            this.vizelbl.Name = "vizelbl";
            this.vizelbl.Size = new System.Drawing.Size(62, 25);
            this.vizelbl.TabIndex = 2;
            this.vizelbl.Text = "Vize:";
            // 
            // notlbl
            // 
            this.notlbl.AutoSize = true;
            this.notlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.notlbl.Location = new System.Drawing.Point(238, 18);
            this.notlbl.Name = "notlbl";
            this.notlbl.Size = new System.Drawing.Size(242, 32);
            this.notlbl.TabIndex = 0;
            this.notlbl.Text = "Not Giriş Sistemi";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button1.Location = new System.Drawing.Point(677, 21);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(88, 31);
            this.button1.TabIndex = 4;
            this.button1.Text = "Çıkış";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button2.Location = new System.Drawing.Point(668, 6);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(88, 31);
            this.button2.TabIndex = 15;
            this.button2.Text = "Çıkış";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.IndianRed;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form5";
            this.Text = "Öğretmen Sistemi";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button görüntülebtn;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox harfnotutxt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox derskodutxt;
        private System.Windows.Forms.Label derskodulbl;
        private System.Windows.Forms.TextBox notxt;
        private System.Windows.Forms.Label öğrenciid;
        private System.Windows.Forms.Button kaydetbtn;
        private System.Windows.Forms.TextBox büttxt;
        private System.Windows.Forms.TextBox finaltxt;
        private System.Windows.Forms.TextBox vizetxt;
        private System.Windows.Forms.Label bütünleme;
        private System.Windows.Forms.Label finallbl;
        private System.Windows.Forms.Label vizelbl;
        private System.Windows.Forms.Label notlbl;
        private System.Windows.Forms.TextBox emailtxt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}