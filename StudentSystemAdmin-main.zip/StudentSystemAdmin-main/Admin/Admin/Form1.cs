﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Data.SqlClient;
namespace Admin
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        SqlConnection conn;
        SqlDataReader rd;
        SqlCommand com;
        private void button1_Click(object sender, EventArgs e)
        {
            string user = label2.Text;
            string password = label3.Text;
            conn = new SqlConnection("Data Source=DESKTOP-3DNAMQC;Initial Catalog=adonet;Integrated Security=True");
            com = new SqlCommand();
            conn.Open();
            com.Connection = conn;
            com.CommandText = "Select email,password From admin Where email='" + emailtxt.Text + "'And password='" + şifretxt.Text + "' ";
            ; rd = com.ExecuteReader();
            if (rd.Read())
            {
                MessageBox.Show("Giriş Başarılı");
                Form2 form2 = new Form2();
                form2.Show();  
                this.Hide();


            }
            else
            {
                MessageBox.Show("Hatalı email ve ya şifre");
            }
            conn.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void emailtxt_TextChanged(object sender, EventArgs e)
        {
            emailtxt.ForeColor = Color.DarkBlue;
        }

        private void şifretxt_TextChanged(object sender, EventArgs e)
        {
            şifretxt.ForeColor = Color.DarkBlue;
            şifretxt.PasswordChar = '*';

        }

        private void button1_MouseHover(object sender, EventArgs e)
        {

            button1.BackColor = Color.Black;
            button1.ForeColor = Color.White;
        }
    }
}
