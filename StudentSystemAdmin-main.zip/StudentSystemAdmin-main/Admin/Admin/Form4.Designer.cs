﻿namespace Admin
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form4));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.notxt = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.görüntülebtn = new System.Windows.Forms.Button();
            this.listView1 = new System.Windows.Forms.ListView();
            this.DersAdı = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.DersGünü = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.DersSaati = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Derslik = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.önotxt = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.sonuçbtn = new System.Windows.Forms.Button();
            this.listView2 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Vize = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.button1 = new System.Windows.Forms.Button();
            this.ders_kayıt = new System.Windows.Forms.Label();
            this.gün_saat_derslik = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.ders_adları = new System.Windows.Forms.ComboBox();
            this.ders_adı = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Location = new System.Drawing.Point(0, -2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(801, 455);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.button2);
            this.tabPage2.Controls.Add(this.notxt);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.listBox1);
            this.tabPage2.Controls.Add(this.görüntülebtn);
            this.tabPage2.Controls.Add(this.listView1);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(793, 426);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Ders Programı";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // notxt
            // 
            this.notxt.Location = new System.Drawing.Point(674, 120);
            this.notxt.Name = "notxt";
            this.notxt.Size = new System.Drawing.Size(100, 22);
            this.notxt.TabIndex = 5;
            this.notxt.TextChanged += new System.EventHandler(this.notxt_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.MistyRose;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(670, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 20);
            this.label2.TabIndex = 4;
            this.label2.Text = "Öğrenci No:";
            // 
            // listBox1
            // 
            this.listBox1.BackColor = System.Drawing.Color.MistyRose;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Location = new System.Drawing.Point(14, 33);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(646, 356);
            this.listBox1.TabIndex = 3;
            // 
            // görüntülebtn
            // 
            this.görüntülebtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.görüntülebtn.Location = new System.Drawing.Point(666, 190);
            this.görüntülebtn.Name = "görüntülebtn";
            this.görüntülebtn.Size = new System.Drawing.Size(114, 29);
            this.görüntülebtn.TabIndex = 2;
            this.görüntülebtn.Text = "Görüntüle";
            this.görüntülebtn.UseVisualStyleBackColor = true;
            this.görüntülebtn.Click += new System.EventHandler(this.görüntülebtn_Click);
            this.görüntülebtn.MouseHover += new System.EventHandler(this.görüntülebtn_MouseHover);
            // 
            // listView1
            // 
            this.listView1.BackColor = System.Drawing.Color.MistyRose;
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.DersAdı,
            this.DersGünü,
            this.DersSaati,
            this.Derslik});
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(6, 7);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(779, 406);
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // DersAdı
            // 
            this.DersAdı.Text = "Ders Adı";
            this.DersAdı.Width = 191;
            // 
            // DersGünü
            // 
            this.DersGünü.Text = "Ders Günü";
            this.DersGünü.Width = 173;
            // 
            // DersSaati
            // 
            this.DersSaati.Text = "Ders Saati";
            this.DersSaati.Width = 153;
            // 
            // Derslik
            // 
            this.Derslik.Text = "Derslik";
            this.Derslik.Width = 118;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.MistyRose;
            this.tabPage3.Controls.Add(this.button3);
            this.tabPage3.Controls.Add(this.önotxt);
            this.tabPage3.Controls.Add(this.label3);
            this.tabPage3.Controls.Add(this.listBox2);
            this.tabPage3.Controls.Add(this.sonuçbtn);
            this.tabPage3.Controls.Add(this.listView2);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(793, 426);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Sınav Sonuçları";
            // 
            // önotxt
            // 
            this.önotxt.Location = new System.Drawing.Point(664, 143);
            this.önotxt.Name = "önotxt";
            this.önotxt.Size = new System.Drawing.Size(120, 22);
            this.önotxt.TabIndex = 6;
            this.önotxt.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(648, 109);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(149, 18);
            this.label3.TabIndex = 5;
            this.label3.Text = "Öğrenci Numarası:";
            // 
            // listBox2
            // 
            this.listBox2.BackColor = System.Drawing.Color.MistyRose;
            this.listBox2.FormattingEnabled = true;
            this.listBox2.ItemHeight = 16;
            this.listBox2.Location = new System.Drawing.Point(14, 35);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(629, 356);
            this.listBox2.TabIndex = 4;
            // 
            // sonuçbtn
            // 
            this.sonuçbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.sonuçbtn.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.sonuçbtn.Location = new System.Drawing.Point(649, 248);
            this.sonuçbtn.Name = "sonuçbtn";
            this.sonuçbtn.Size = new System.Drawing.Size(141, 44);
            this.sonuçbtn.TabIndex = 3;
            this.sonuçbtn.Text = "Görüntüle";
            this.sonuçbtn.UseVisualStyleBackColor = true;
            this.sonuçbtn.Click += new System.EventHandler(this.sonuçbtn_Click_1);
            // 
            // listView2
            // 
            this.listView2.BackColor = System.Drawing.Color.MistyRose;
            this.listView2.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.Vize,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader2});
            this.listView2.HideSelection = false;
            this.listView2.Location = new System.Drawing.Point(8, 3);
            this.listView2.Name = "listView2";
            this.listView2.Size = new System.Drawing.Size(642, 420);
            this.listView2.TabIndex = 2;
            this.listView2.UseCompatibleStateImageBehavior = false;
            this.listView2.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Ders Adı";
            this.columnHeader1.Width = 156;
            // 
            // Vize
            // 
            this.Vize.Text = "Vize";
            this.Vize.Width = 133;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Final";
            this.columnHeader3.Width = 153;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Bütünleme";
            this.columnHeader4.Width = 118;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Harf Notu";
            this.columnHeader2.Width = 138;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.MistyRose;
            this.tabPage1.Controls.Add(this.button4);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.ders_kayıt);
            this.tabPage1.Controls.Add(this.gün_saat_derslik);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.ders_adları);
            this.tabPage1.Controls.Add(this.ders_adı);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(793, 426);
            this.tabPage1.TabIndex = 3;
            this.tabPage1.Text = "Ders Kaydı";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button1.Location = new System.Drawing.Point(220, 311);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(203, 69);
            this.button1.TabIndex = 5;
            this.button1.Text = "KAYDET";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            this.button1.MouseHover += new System.EventHandler(this.button1_MouseHover);
            // 
            // ders_kayıt
            // 
            this.ders_kayıt.AutoSize = true;
            this.ders_kayıt.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.ders_kayıt.Location = new System.Drawing.Point(203, 13);
            this.ders_kayıt.Name = "ders_kayıt";
            this.ders_kayıt.Size = new System.Drawing.Size(338, 32);
            this.ders_kayıt.TabIndex = 4;
            this.ders_kayıt.Text = "ÖĞRENCİ DERS KAYDI";
            // 
            // gün_saat_derslik
            // 
            this.gün_saat_derslik.FormattingEnabled = true;
            this.gün_saat_derslik.Items.AddRange(new object[] {
            "Pazartesi 10.30- Perşembe 13.30 MA112",
            "Salı 08.30-Çarşamba 15.30 - MA313",
            "Salı 08.30 - Çarşamba 15.30 -MA112",
            "Cuma 15.30 -Perşembe 10.30 - MA113",
            "Pazartesi 13.30 - Salı 13.30 MA116",
            "Cuma 10.30 - Perşembe 15.30 MA108",
            "Pazartesi 13.30 - Salı 13.30 - MA 206",
            "Salı 13.30 -Çarşamba 13.30 - MA106",
            "Pazartesi 08.30 -Salı 08.30 - MA104",
            "Cuma 15.30- Perşembe 10.30 - MA113",
            "Salı 08.30-Çarşamba 15.30 - Ma313",
            "Pazartesi 13.30- Salı 13.30",
            "Pazartesi 13.30 -Salı 13.30 - MA 206"});
            this.gün_saat_derslik.Location = new System.Drawing.Point(255, 233);
            this.gün_saat_derslik.Name = "gün_saat_derslik";
            this.gün_saat_derslik.Size = new System.Drawing.Size(222, 24);
            this.gün_saat_derslik.TabIndex = 3;
            this.gün_saat_derslik.SelectedIndexChanged += new System.EventHandler(this.gün_saat_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(73, 233);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(164, 22);
            this.label1.TabIndex = 2;
            this.label1.Text = "Gün-Saat-Derslik";
            // 
            // ders_adları
            // 
            this.ders_adları.FormattingEnabled = true;
            this.ders_adları.Items.AddRange(new object[] {
            "Calculus1",
            "Calculus2",
            "Fizik1",
            "Fİzik2",
            "Lİneear Cebir",
            "Diferansiyel Denklemler",
            "Mühendisliğe Giriş ",
            "Algoritma ve Programlama",
            "Nesneye Yönelik Programlama",
            "Web "});
            this.ders_adları.Location = new System.Drawing.Point(255, 132);
            this.ders_adları.Name = "ders_adları";
            this.ders_adları.Size = new System.Drawing.Size(222, 24);
            this.ders_adları.TabIndex = 1;
            // 
            // ders_adı
            // 
            this.ders_adı.AutoSize = true;
            this.ders_adı.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.ders_adı.Location = new System.Drawing.Point(73, 132);
            this.ders_adı.Name = "ders_adı";
            this.ders_adı.Size = new System.Drawing.Size(93, 22);
            this.ders_adı.TabIndex = 0;
            this.ders_adı.Text = "Ders Adı:";
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(692, 381);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(82, 32);
            this.button2.TabIndex = 6;
            this.button2.Text = "Çıkış";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(702, 391);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(82, 32);
            this.button3.TabIndex = 7;
            this.button3.Text = "Çıkış";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(690, 373);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(82, 32);
            this.button4.TabIndex = 7;
            this.button4.Text = "Çıkış";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.IndianRed;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form4";
            this.Text = "Öğrenci Sistemi";
            this.Load += new System.EventHandler(this.Form4_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button görüntülebtn;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader DersAdı;
        private System.Windows.Forms.ColumnHeader DersGünü;
        private System.Windows.Forms.ColumnHeader DersSaati;
        private System.Windows.Forms.ColumnHeader Derslik;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label ders_kayıt;
        private System.Windows.Forms.ComboBox gün_saat_derslik;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox ders_adları;
        private System.Windows.Forms.Label ders_adı;
        private System.Windows.Forms.TextBox notxt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.Button sonuçbtn;
        private System.Windows.Forms.ListView listView2;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader Vize;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.TextBox önotxt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
    }
}