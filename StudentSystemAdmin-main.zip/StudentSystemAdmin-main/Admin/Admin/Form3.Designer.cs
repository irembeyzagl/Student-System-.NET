﻿namespace Admin
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.passwordtxtx = new System.Windows.Forms.TextBox();
            this.mailtxt = new System.Windows.Forms.TextBox();
            this.passwordlbl = new System.Windows.Forms.Label();
            this.maillbl = new System.Windows.Forms.Label();
            this.lblMesaj = new System.Windows.Forms.Label();
            this.btnEkle = new System.Windows.Forms.Button();
            this.dilcombo = new System.Windows.Forms.ComboBox();
            this.bölümtxt = new System.Windows.Forms.TextBox();
            this.okulnotxt = new System.Windows.Forms.TextBox();
            this.soyadtxt = new System.Windows.Forms.TextBox();
            this.adtxt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.resimbox = new System.Windows.Forms.PictureBox();
            this.dillbl = new System.Windows.Forms.Label();
            this.bölümlbl = new System.Windows.Forms.Label();
            this.nolbl = new System.Windows.Forms.Label();
            this.soyadlbl = new System.Windows.Forms.Label();
            this.adlbl = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.no_txt = new System.Windows.Forms.TextBox();
            this.soyad_txt = new System.Windows.Forms.TextBox();
            this.adtxt2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnSis = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.resimbox)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(0, 1);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(800, 448);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.MistyRose;
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Controls.Add(this.passwordtxtx);
            this.tabPage1.Controls.Add(this.mailtxt);
            this.tabPage1.Controls.Add(this.passwordlbl);
            this.tabPage1.Controls.Add(this.maillbl);
            this.tabPage1.Controls.Add(this.lblMesaj);
            this.tabPage1.Controls.Add(this.btnEkle);
            this.tabPage1.Controls.Add(this.dilcombo);
            this.tabPage1.Controls.Add(this.bölümtxt);
            this.tabPage1.Controls.Add(this.okulnotxt);
            this.tabPage1.Controls.Add(this.soyadtxt);
            this.tabPage1.Controls.Add(this.adtxt);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.resimbox);
            this.tabPage1.Controls.Add(this.dillbl);
            this.tabPage1.Controls.Add(this.bölümlbl);
            this.tabPage1.Controls.Add(this.nolbl);
            this.tabPage1.Controls.Add(this.soyadlbl);
            this.tabPage1.Controls.Add(this.adlbl);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(792, 419);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "EKLEME";
            // 
            // passwordtxtx
            // 
            this.passwordtxtx.Location = new System.Drawing.Point(562, 382);
            this.passwordtxtx.Name = "passwordtxtx";
            this.passwordtxtx.Size = new System.Drawing.Size(196, 22);
            this.passwordtxtx.TabIndex = 36;
            // 
            // mailtxt
            // 
            this.mailtxt.Location = new System.Drawing.Point(192, 379);
            this.mailtxt.Name = "mailtxt";
            this.mailtxt.Size = new System.Drawing.Size(197, 22);
            this.mailtxt.TabIndex = 35;
            // 
            // passwordlbl
            // 
            this.passwordlbl.AutoSize = true;
            this.passwordlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.passwordlbl.Location = new System.Drawing.Point(438, 382);
            this.passwordlbl.Name = "passwordlbl";
            this.passwordlbl.Size = new System.Drawing.Size(97, 20);
            this.passwordlbl.TabIndex = 34;
            this.passwordlbl.Text = "Password:";
            // 
            // maillbl
            // 
            this.maillbl.AutoSize = true;
            this.maillbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.maillbl.Location = new System.Drawing.Point(43, 379);
            this.maillbl.Name = "maillbl";
            this.maillbl.Size = new System.Drawing.Size(62, 20);
            this.maillbl.TabIndex = 33;
            this.maillbl.Text = "Email:";
            // 
            // lblMesaj
            // 
            this.lblMesaj.AutoSize = true;
            this.lblMesaj.Location = new System.Drawing.Point(662, 389);
            this.lblMesaj.Name = "lblMesaj";
            this.lblMesaj.Size = new System.Drawing.Size(0, 16);
            this.lblMesaj.TabIndex = 32;
            // 
            // btnEkle
            // 
            this.btnEkle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnEkle.Location = new System.Drawing.Point(629, 258);
            this.btnEkle.Name = "btnEkle";
            this.btnEkle.Size = new System.Drawing.Size(130, 52);
            this.btnEkle.TabIndex = 31;
            this.btnEkle.Text = "EKLE";
            this.btnEkle.UseVisualStyleBackColor = true;
            this.btnEkle.Click += new System.EventHandler(this.btnEkle_Click_1);
            // 
            // dilcombo
            // 
            this.dilcombo.FormattingEnabled = true;
            this.dilcombo.Items.AddRange(new object[] {
            "Türkçe",
            "İngilizce"});
            this.dilcombo.Location = new System.Drawing.Point(191, 325);
            this.dilcombo.Name = "dilcombo";
            this.dilcombo.Size = new System.Drawing.Size(201, 24);
            this.dilcombo.TabIndex = 30;
            // 
            // bölümtxt
            // 
            this.bölümtxt.Location = new System.Drawing.Point(191, 276);
            this.bölümtxt.Name = "bölümtxt";
            this.bölümtxt.Size = new System.Drawing.Size(337, 22);
            this.bölümtxt.TabIndex = 29;
            // 
            // okulnotxt
            // 
            this.okulnotxt.Location = new System.Drawing.Point(192, 219);
            this.okulnotxt.Name = "okulnotxt";
            this.okulnotxt.Size = new System.Drawing.Size(336, 22);
            this.okulnotxt.TabIndex = 28;
            // 
            // soyadtxt
            // 
            this.soyadtxt.Location = new System.Drawing.Point(192, 166);
            this.soyadtxt.Name = "soyadtxt";
            this.soyadtxt.Size = new System.Drawing.Size(333, 22);
            this.soyadtxt.TabIndex = 27;
            // 
            // adtxt
            // 
            this.adtxt.Location = new System.Drawing.Point(191, 114);
            this.adtxt.Name = "adtxt";
            this.adtxt.Size = new System.Drawing.Size(333, 22);
            this.adtxt.TabIndex = 26;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(190, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(265, 29);
            this.label1.TabIndex = 25;
            this.label1.Text = "Öğrenci Kayıt Ekleme";
            // 
            // resimbox
            // 
            this.resimbox.Location = new System.Drawing.Point(629, 42);
            this.resimbox.Name = "resimbox";
            this.resimbox.Size = new System.Drawing.Size(122, 134);
            this.resimbox.TabIndex = 24;
            this.resimbox.TabStop = false;
            // 
            // dillbl
            // 
            this.dillbl.AutoSize = true;
            this.dillbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.dillbl.Location = new System.Drawing.Point(42, 325);
            this.dillbl.Name = "dillbl";
            this.dillbl.Size = new System.Drawing.Size(39, 20);
            this.dillbl.TabIndex = 23;
            this.dillbl.Text = "Dil:";
            // 
            // bölümlbl
            // 
            this.bölümlbl.AutoSize = true;
            this.bölümlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.bölümlbl.Location = new System.Drawing.Point(42, 276);
            this.bölümlbl.Name = "bölümlbl";
            this.bölümlbl.Size = new System.Drawing.Size(68, 20);
            this.bölümlbl.TabIndex = 22;
            this.bölümlbl.Text = "Bölüm:";
            // 
            // nolbl
            // 
            this.nolbl.AutoSize = true;
            this.nolbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.nolbl.Location = new System.Drawing.Point(41, 219);
            this.nolbl.Name = "nolbl";
            this.nolbl.Size = new System.Drawing.Size(139, 20);
            this.nolbl.TabIndex = 21;
            this.nolbl.Text = "Okul Numarası:";
            // 
            // soyadlbl
            // 
            this.soyadlbl.AutoSize = true;
            this.soyadlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.soyadlbl.Location = new System.Drawing.Point(41, 166);
            this.soyadlbl.Name = "soyadlbl";
            this.soyadlbl.Size = new System.Drawing.Size(138, 20);
            this.soyadlbl.TabIndex = 20;
            this.soyadlbl.Text = "Öğrenci Soyad:";
            // 
            // adlbl
            // 
            this.adlbl.AutoSize = true;
            this.adlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.adlbl.Location = new System.Drawing.Point(41, 114);
            this.adlbl.Name = "adlbl";
            this.adlbl.Size = new System.Drawing.Size(114, 20);
            this.adlbl.TabIndex = 19;
            this.adlbl.Text = "Öğrenci Adı:";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.MistyRose;
            this.tabPage2.Controls.Add(this.button1);
            this.tabPage2.Controls.Add(this.no_txt);
            this.tabPage2.Controls.Add(this.soyad_txt);
            this.tabPage2.Controls.Add(this.adtxt2);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.btnSis);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(792, 419);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "SİLME";
            // 
            // no_txt
            // 
            this.no_txt.Location = new System.Drawing.Point(263, 233);
            this.no_txt.Name = "no_txt";
            this.no_txt.Size = new System.Drawing.Size(336, 22);
            this.no_txt.TabIndex = 45;
            // 
            // soyad_txt
            // 
            this.soyad_txt.Location = new System.Drawing.Point(263, 180);
            this.soyad_txt.Name = "soyad_txt";
            this.soyad_txt.Size = new System.Drawing.Size(333, 22);
            this.soyad_txt.TabIndex = 44;
            // 
            // adtxt2
            // 
            this.adtxt2.Location = new System.Drawing.Point(262, 128);
            this.adtxt2.Name = "adtxt2";
            this.adtxt2.Size = new System.Drawing.Size(333, 22);
            this.adtxt2.TabIndex = 43;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(112, 233);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(139, 20);
            this.label3.TabIndex = 42;
            this.label3.Text = "Okul Numarası:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(112, 180);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(138, 20);
            this.label4.TabIndex = 41;
            this.label4.Text = "Öğrenci Soyad:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.Location = new System.Drawing.Point(112, 128);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(114, 20);
            this.label5.TabIndex = 40;
            this.label5.Text = "Öğrenci Adı:";
            // 
            // btnSis
            // 
            this.btnSis.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnSis.Location = new System.Drawing.Point(272, 305);
            this.btnSis.Name = "btnSis";
            this.btnSis.Size = new System.Drawing.Size(130, 52);
            this.btnSis.TabIndex = 39;
            this.btnSis.Text = "SİL";
            this.btnSis.UseVisualStyleBackColor = true;
            this.btnSis.Click += new System.EventHandler(this.btnSil_Click_1);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(229, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(244, 29);
            this.label2.TabIndex = 35;
            this.label2.Text = "Öğrenci Kayıt Silme";
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button2.Location = new System.Drawing.Point(702, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(82, 34);
            this.button2.TabIndex = 37;
            this.button2.Text = "Çıkış";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button1.Location = new System.Drawing.Point(688, 365);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(82, 34);
            this.button1.TabIndex = 46;
            this.button1.Text = "Çıkış";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form3";
            this.Text = "Öğrenci Sayfası:";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.resimbox)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox passwordtxtx;
        private System.Windows.Forms.TextBox mailtxt;
        private System.Windows.Forms.Label passwordlbl;
        private System.Windows.Forms.Label maillbl;
        private System.Windows.Forms.Label lblMesaj;
        private System.Windows.Forms.Button btnEkle;
        private System.Windows.Forms.ComboBox dilcombo;
        private System.Windows.Forms.TextBox bölümtxt;
        private System.Windows.Forms.TextBox okulnotxt;
        private System.Windows.Forms.TextBox soyadtxt;
        private System.Windows.Forms.TextBox adtxt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox resimbox;
        private System.Windows.Forms.Label dillbl;
        private System.Windows.Forms.Label bölümlbl;
        private System.Windows.Forms.Label nolbl;
        private System.Windows.Forms.Label soyadlbl;
        private System.Windows.Forms.Label adlbl;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox no_txt;
        private System.Windows.Forms.TextBox soyad_txt;
        private System.Windows.Forms.TextBox adtxt2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnSis;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
    }
}