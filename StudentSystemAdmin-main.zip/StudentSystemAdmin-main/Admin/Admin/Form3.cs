﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Admin
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void dilcombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            dilcombo.Items.Add("Türkçe");
            dilcombo.Items.Add("İngilizce");

        }
      

        private void resimbox_Click(object sender, EventArgs e)
        {

        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void adtxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void adlbl_Click(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {
            tabPage1.BackColor = Color.Red;
        }

        private void soyadtxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void soyadlbl_Click(object sender, EventArgs e)
        {

        }

        private void nolbl_Click(object sender, EventArgs e)
        {

        }

        private void okulnotxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        
        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnEkle_Click_1(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection();
            conn = new SqlConnection("Data Source=DESKTOP-3DNAMQC;Initial Catalog=adonet;Integrated Security=True");
            conn.Open();
            string ad = adtxt.Text;
            string soyad = soyadtxt.Text;
            string no = okulnotxt.Text;
            string bölüm = bölümtxt.Text;
            string dil = dilcombo.Text;
            string mail = mailtxt.Text;
            string password = passwordtxtx.Text;


            string kayit = "Insert INTO öğrenci (öğrenci_adı,öğrenci_soyadı,öğrenci_no,bölüm,dil,email,password) VALUES (@ad, @soyad, @no, @bölüm,@dil,@mail,@password)";



            SqlCommand cmd = new SqlCommand(kayit, conn);
            cmd.Parameters.AddWithValue("@ad", adtxt.Text);
            cmd.Parameters.AddWithValue("@soyad", soyadtxt.Text);
            cmd.Parameters.AddWithValue("@no", okulnotxt.Text);
            cmd.Parameters.AddWithValue("@bölüm", bölümtxt.Text);
            cmd.Parameters.AddWithValue("@dil", dilcombo.Text);
            cmd.Parameters.AddWithValue("@mail", mailtxt.Text);
            cmd.Parameters.AddWithValue("@password", passwordtxtx.Text);
            cmd.ExecuteNonQuery();

            conn.Close();
            lblMesaj.Visible = true;
            lblMesaj.ForeColor = Color.Green;
            lblMesaj.Text = "Öğrenci Başarıyla Kaydedildi";
        }

        private void btnSil_Click_1(object sender, EventArgs e)
        {
            string ad = adtxt2.Text;
            string soyad = soyad_txt.Text;
            string no = no_txt.Text;
            SqlConnection baglanti = new SqlConnection();
            baglanti = new SqlConnection("Data Source=DESKTOP-3DNAMQC;Initial Catalog=adonet;Integrated Security=True");
            baglanti.Open();
            SqlCommand VeriSil = new SqlCommand("Delete from öğrenci where öğrenci_adı='" + adtxt2.Text + "'and öğrenci_soyadı='" + soyad_txt.Text + "'and öğrenci_no='" + no_txt.Text + "'", baglanti);
            VeriSil.Parameters.AddWithValue("ad", adtxt2.Text);
            VeriSil.Parameters.AddWithValue("soyad", soyad_txt.Text);
            VeriSil.Parameters.AddWithValue("no", no_txt.Text);
            VeriSil.ExecuteNonQuery();
            baglanti.Close();

            MessageBox.Show("Veri silindi");
        }

        private void bölümtxt_TextChanged(object sender, EventArgs e)
        {
            bölümtxt.ForeColor = Color.DarkBlue;
        }

        private void mailtxt_TextChanged(object sender, EventArgs e)
        {
            mailtxt.ForeColor = Color.DarkBlue;
        }

        private void passwordtxtx_TextChanged(object sender, EventArgs e)
        {
            passwordtxtx.ForeColor = Color.DarkBlue;
            passwordtxtx.PasswordChar = '*';
        }

        private void btnSis_MouseHover(object sender, EventArgs e)
        {
            btnSis.BackColor = Color.Black;
            btnSis.ForeColor = Color.White;


        }
        private void ad_txt_TextChanged(object sender, EventArgs e)
        {
            adtxt2.ForeColor = Color.DarkBlue;
        }
        private void btnSis_MouseLeave(object sender, EventArgs e)
        {
            btnSis.BackColor = Color.White;
            btnSis.ForeColor = Color.Black;
            btnSis.BringToFront();
        }

        private void btnEkle_MouseHover(object sender, EventArgs e)
        {
            btnEkle.BackColor = Color.Black;
            btnEkle.ForeColor = Color.White;
        }
        private void btnEkle_MouseLeave(object sender, EventArgs e)
        {
            btnEkle.BackColor = Color.White;
            btnEkle.ForeColor = Color.Black;
            btnEkle.BringToFront();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.GetCurrentProcess().Kill();
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.GetCurrentProcess().Kill();
            Application.Exit();
        }
    }
}

