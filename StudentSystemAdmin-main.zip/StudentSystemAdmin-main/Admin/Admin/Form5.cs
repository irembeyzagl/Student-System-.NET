﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data;
using System.Data.SqlClient;
using System.Reflection.Emit;
using Admin;

namespace Admin
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }


        private void Form5_Load(object sender, EventArgs e)
        {

        }



        SqlConnection conn = new SqlConnection("Data Source=DESKTOP-3DNAMQC;Initial Catalog=adonet;Integrated Security=True");
        
        private void görüntülebtn_Click(object sender, EventArgs e)
        {
            string email = emailtxt.Text;
            listBox1.Items.Clear();
            conn.Open();
            SqlCommand cmd = new SqlCommand("Select ders_adı,ders_kodu,ders_günü,ders_saati,derslik from öğrenci_ders_programı inner " +
                "join öğretmen on öğretmen.ders_programı_id=öğrenci_ders_programı.id where öğretmen.email='" + email + "'", conn);
            SqlDataReader rdr = cmd.ExecuteReader();

            while (rdr.Read())
            {
                listBox1.Items.Add(rdr[0] + "        " + rdr[1] + "        " + rdr[2] + "        " + rdr[3] + "        " + rdr[4]);
            }
            conn.Close();
        }

       

        private void kaydetbtn_Click_1(object sender, EventArgs e)
        {
            string vize = vizetxt.Text;
            string final = finaltxt.Text;
            string bütünleme = büttxt.Text;
            int no = Convert.ToInt32(notxt.Text);
            int ders_kodu = Convert.ToInt32(derskodutxt.Text);
            string harf_notu = harfnotutxt.Text;

            string kayit = "Insert INTO sınav_sonuçları (vize,final,bütünleme,ders_id,öğrenci_id,harf_notu) VALUES (@vize, @final, @bütünleme,@derskodu,@no,@harf_notu)";



            SqlCommand cmd = new SqlCommand(kayit, conn);
            if (vize != null || final != null || bütünleme != null)
            {
                cmd.Parameters.AddWithValue("@vize", vize);
                cmd.Parameters.AddWithValue("@final", final);
                cmd.Parameters.AddWithValue("@bütünleme", bütünleme);
            }

            cmd.Parameters.AddWithValue("@derskodu", ders_kodu);
            cmd.Parameters.AddWithValue("@no", no);
            cmd.Parameters.AddWithValue("@harf_notu", harf_notu);
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }
            cmd.ExecuteNonQuery();

            conn.Close();

            MessageBox.Show("Başarıyla Kaydedildi");

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void emailtxt_TextChanged(object sender, EventArgs e)
        {
            emailtxt.ForeColor = Color.DarkBlue;
        }

        private void görüntülebtn_MouseHover(object sender, EventArgs e)
        {
            görüntülebtn.BackColor = Color.Black;
            görüntülebtn.ForeColor = Color.White;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            harfnotutxt.ForeColor = Color.DarkBlue;
        }

        

        private void notxt_TextChanged(object sender, EventArgs e)
        {
            notxt.ForeColor = Color.DarkBlue;
        }

        private void derskodutxt_TextChanged(object sender, EventArgs e)
        {
            derskodutxt.ForeColor = Color.DarkBlue;
        }

        private void vizetxt_TextChanged(object sender, EventArgs e)
        {
            vizetxt.ForeColor = Color.DarkBlue;
        }
        private void vizetxt_TextChanged_1(object sender, EventArgs e)
        {
            vizetxt.ForeColor = Color.DarkBlue;
        }
        private void finaltxt_TextChanged(object sender, EventArgs e)
        {
            finaltxt.ForeColor = Color.DarkBlue;
        }

        private void büttxt_TextChanged(object sender, EventArgs e)
        {
            büttxt.ForeColor = Color.DarkBlue;
        }

        private void kaydetbtn_MouseHover(object sender, EventArgs e)
        {
            kaydetbtn.BackColor = Color.Black;
            kaydetbtn.ForeColor = Color.White;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.GetCurrentProcess().Kill();
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.GetCurrentProcess().Kill();
            Application.Exit();
        }
    }
}
