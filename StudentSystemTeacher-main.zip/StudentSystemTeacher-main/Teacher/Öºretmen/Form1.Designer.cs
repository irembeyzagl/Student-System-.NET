﻿namespace Öğretmen
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.başlıklbl = new System.Windows.Forms.Label();
            this.emaillbl = new System.Windows.Forms.Label();
            this.şifrelbl = new System.Windows.Forms.Label();
            this.emailtxt = new System.Windows.Forms.TextBox();
            this.şifretxt = new System.Windows.Forms.TextBox();
            this.girişbtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // başlıklbl
            // 
            this.başlıklbl.AutoSize = true;
            this.başlıklbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.başlıklbl.Location = new System.Drawing.Point(229, 32);
            this.başlıklbl.Name = "başlıklbl";
            this.başlıklbl.Size = new System.Drawing.Size(329, 32);
            this.başlıklbl.TabIndex = 0;
            this.başlıklbl.Text = "Öğretmen Giriş Sistemi";
            // 
            // emaillbl
            // 
            this.emaillbl.AutoSize = true;
            this.emaillbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.emaillbl.Location = new System.Drawing.Point(187, 173);
            this.emaillbl.Name = "emaillbl";
            this.emaillbl.Size = new System.Drawing.Size(73, 22);
            this.emaillbl.TabIndex = 1;
            this.emaillbl.Text = "EMAİL:";
            // 
            // şifrelbl
            // 
            this.şifrelbl.AutoSize = true;
            this.şifrelbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.şifrelbl.Location = new System.Drawing.Point(187, 272);
            this.şifrelbl.Name = "şifrelbl";
            this.şifrelbl.Size = new System.Drawing.Size(73, 22);
            this.şifrelbl.TabIndex = 2;
            this.şifrelbl.Text = "ŞİFRE:";
            // 
            // emailtxt
            // 
            this.emailtxt.Location = new System.Drawing.Point(318, 175);
            this.emailtxt.Name = "emailtxt";
            this.emailtxt.Size = new System.Drawing.Size(240, 22);
            this.emailtxt.TabIndex = 3;
            this.emailtxt.TextChanged += new System.EventHandler(this.emailtxt_TextChanged);
            // 
            // şifretxt
            // 
            this.şifretxt.Location = new System.Drawing.Point(318, 274);
            this.şifretxt.Name = "şifretxt";
            this.şifretxt.Size = new System.Drawing.Size(240, 22);
            this.şifretxt.TabIndex = 4;
            this.şifretxt.TextChanged += new System.EventHandler(this.şifretxt_TextChanged);
            // 
            // girişbtn
            // 
            this.girişbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.girişbtn.Location = new System.Drawing.Point(295, 372);
            this.girişbtn.Name = "girişbtn";
            this.girişbtn.Size = new System.Drawing.Size(177, 52);
            this.girişbtn.TabIndex = 5;
            this.girişbtn.Text = "GİRİŞ";
            this.girişbtn.UseVisualStyleBackColor = true;
            this.girişbtn.Click += new System.EventHandler(this.girişbtn_Click);
            this.girişbtn.MouseHover += new System.EventHandler(this.girişbtn_MouseHover);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MistyRose;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.girişbtn);
            this.Controls.Add(this.şifretxt);
            this.Controls.Add(this.emailtxt);
            this.Controls.Add(this.şifrelbl);
            this.Controls.Add(this.emaillbl);
            this.Controls.Add(this.başlıklbl);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Öğretmen Sayfası";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label başlıklbl;
        private System.Windows.Forms.Label emaillbl;
        private System.Windows.Forms.Label şifrelbl;
        private System.Windows.Forms.TextBox emailtxt;
        private System.Windows.Forms.TextBox şifretxt;
        private System.Windows.Forms.Button girişbtn;
    }
}

