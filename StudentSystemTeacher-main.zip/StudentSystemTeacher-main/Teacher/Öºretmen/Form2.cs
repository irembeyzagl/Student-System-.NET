﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data;
using System.Data.SqlClient;
using System.Reflection.Emit;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Globalization;
using System.Security.Cryptography.X509Certificates;

namespace Öğretmen
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        public void çiz()
        {
            
                SqlConnection conn = new SqlConnection();
                conn = new SqlConnection("Data Source=DESKTOP-3DNAMQC;Initial Catalog=adonet;Integrated Security=True");
                conn.Open();
                SqlCommand cmd2 = new SqlCommand("SELECT öğrenci.sınıf,sınav_sonuçları.ortalama FROM öğrenci INNER JOIN sınav_sonuçları ON öğrenci.id = sınav_sonuçları.öğrenci_id where öğrenci_no='" + öğrencinotxt.Text + "'", conn);
                SqlDataReader rdr = cmd2.ExecuteReader();
                while (rdr.Read())
                {

                    chart1.Series["GANO"].Points.AddXY(rdr[0].ToString(), rdr[1].ToString());

                }

                conn.Close();
            
        }
        
        private void Form2_Load(object sender, EventArgs e)
        {
            çiz();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            çiz();
        }

        SqlConnection conn = new SqlConnection("Data Source=DESKTOP-3DNAMQC;Initial Catalog=adonet;Integrated Security=True");
        string email = Form1.göderilecek_değer;
        private void görüntülebtn_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            conn.Open();
            SqlCommand cmd = new SqlCommand("Select ders_adı,ders_kodu,ders_günü,ders_saati,derslik from öğrenci_ders_programı inner " +
                "join öğretmen on öğretmen.ders_programı_id=öğrenci_ders_programı.id where öğretmen.email='" + email+"'",conn);
            SqlDataReader rdr = cmd.ExecuteReader();

            while (rdr.Read()) {
                listBox1.Items.Add(rdr[0] + "        " + rdr[1] + "        " + rdr[2] + "        " + rdr[3] + "        " + rdr[4]);
                              }
            conn.Close();
        }
        
        private void kaydetbtn_Click(object sender, EventArgs e)
        {

            string vize = vizetxt.Text;
            string final =finaltxt.Text;
            string bütünleme = büttxt.Text;
            int no = Convert.ToInt32(notxt.Text);            
            int ders_kodu = Convert.ToInt32(derskodutxt.Text);
            string harf_notu=harfnotutxt.Text;
            float ortalama = float.Parse(ortalamatxt.Text, CultureInfo.InvariantCulture.NumberFormat);
            if (vizetxt.Text ==" ")
            {
                MessageBox.Show("alert");
            }

            string kayit = "Insert INTO sınav_sonuçları (vize,final,bütünleme,ders_id,öğrenci_id,harf_notu,ortalama) VALUES (@vize, @final, @bütünleme,@derskodu,@no,@harf_notu,@ortalama)";
         


            SqlCommand cmd = new SqlCommand(kayit, conn);
                if (vize != null) {
                cmd.Parameters.AddWithValue("@vize", vize);
                }
           
                if (final != null)
                {
                cmd.Parameters.AddWithValue("@final", final);
                }
      
                if (bütünleme != null)
                {
                cmd.Parameters.AddWithValue("@bütünleme", bütünleme);
                }
            


            cmd.Parameters.AddWithValue("@derskodu", ders_kodu);
            cmd.Parameters.AddWithValue("@no", no);
            cmd.Parameters.AddWithValue("@harf_notu", harf_notu);
            cmd.Parameters.AddWithValue("@ortalama", ortalama);
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }
            cmd.ExecuteNonQuery();

            conn.Close();

            MessageBox.Show("Başarıyla Kaydedildi");

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            harfnotutxt.ForeColor = Color.DarkBlue;
        }

        private void görüntülebtn_MouseHover(object sender, EventArgs e)
        {

            görüntülebtn.BackColor = Color.Black;
            görüntülebtn.ForeColor = Color.White;
        }

        private void notxt_TextChanged(object sender, EventArgs e)
        {
            notxt.ForeColor = Color.DarkBlue;
        }

        private void derskodutxt_TextChanged(object sender, EventArgs e)
        {
            derskodutxt.ForeColor = Color.DarkBlue;
        }

        private void vizetxt_TextChanged(object sender, EventArgs e)
        {
            vizetxt.ForeColor = Color.DarkBlue;
        }

        private void finaltxt_TextChanged(object sender, EventArgs e)
        {
            finaltxt.ForeColor = Color.DarkBlue;
        }

        private void büttxt_TextChanged(object sender, EventArgs e)
        {
            büttxt.ForeColor = Color.DarkBlue;
        }

        private void kaydetbtn_MouseHover(object sender, EventArgs e)
        {
            kaydetbtn.BackColor = Color.Black;
            kaydetbtn.ForeColor = Color.White;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.GetCurrentProcess().Kill();
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.GetCurrentProcess().Kill();
            Application.Exit();
        }

        private void tabPage3_Click(object sender, EventArgs e)
        {

        }
       


    }
}
