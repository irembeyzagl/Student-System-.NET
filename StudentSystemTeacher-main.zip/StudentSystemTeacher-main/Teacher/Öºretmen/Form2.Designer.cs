﻿namespace Öğretmen
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title1 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.button1 = new System.Windows.Forms.Button();
            this.görüntülebtn = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.ortalamatxt = new System.Windows.Forms.TextBox();
            this.avglbl = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.harfnotutxt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.derskodutxt = new System.Windows.Forms.TextBox();
            this.derskodulbl = new System.Windows.Forms.Label();
            this.notxt = new System.Windows.Forms.TextBox();
            this.öğrenciid = new System.Windows.Forms.Label();
            this.kaydetbtn = new System.Windows.Forms.Button();
            this.büttxt = new System.Windows.Forms.TextBox();
            this.finaltxt = new System.Windows.Forms.TextBox();
            this.vizetxt = new System.Windows.Forms.TextBox();
            this.bütünleme = new System.Windows.Forms.Label();
            this.finallbl = new System.Windows.Forms.Label();
            this.vizelbl = new System.Windows.Forms.Label();
            this.notlbl = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.button3 = new System.Windows.Forms.Button();
            this.öğrencinotxt = new System.Windows.Forms.TextBox();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(5, 13);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(791, 431);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.MistyRose;
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.görüntülebtn);
            this.tabPage1.Controls.Add(this.listBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(783, 402);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Ders Programı";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button1.Location = new System.Drawing.Point(705, 11);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(78, 30);
            this.button1.TabIndex = 2;
            this.button1.Text = "Çıkış";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // görüntülebtn
            // 
            this.görüntülebtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.görüntülebtn.Location = new System.Drawing.Point(597, 369);
            this.görüntülebtn.Name = "görüntülebtn";
            this.görüntülebtn.Size = new System.Drawing.Size(132, 33);
            this.görüntülebtn.TabIndex = 1;
            this.görüntülebtn.Text = "Görüntüle";
            this.görüntülebtn.UseVisualStyleBackColor = true;
            this.görüntülebtn.Click += new System.EventHandler(this.görüntülebtn_Click);
            this.görüntülebtn.MouseHover += new System.EventHandler(this.görüntülebtn_MouseHover);
            // 
            // listBox1
            // 
            this.listBox1.BackColor = System.Drawing.Color.MistyRose;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Location = new System.Drawing.Point(64, 11);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(637, 356);
            this.listBox1.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.MistyRose;
            this.tabPage2.Controls.Add(this.ortalamatxt);
            this.tabPage2.Controls.Add(this.avglbl);
            this.tabPage2.Controls.Add(this.button2);
            this.tabPage2.Controls.Add(this.harfnotutxt);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.derskodutxt);
            this.tabPage2.Controls.Add(this.derskodulbl);
            this.tabPage2.Controls.Add(this.notxt);
            this.tabPage2.Controls.Add(this.öğrenciid);
            this.tabPage2.Controls.Add(this.kaydetbtn);
            this.tabPage2.Controls.Add(this.büttxt);
            this.tabPage2.Controls.Add(this.finaltxt);
            this.tabPage2.Controls.Add(this.vizetxt);
            this.tabPage2.Controls.Add(this.bütünleme);
            this.tabPage2.Controls.Add(this.finallbl);
            this.tabPage2.Controls.Add(this.vizelbl);
            this.tabPage2.Controls.Add(this.notlbl);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(783, 402);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Not Sistemi";
            // 
            // ortalamatxt
            // 
            this.ortalamatxt.Location = new System.Drawing.Point(592, 123);
            this.ortalamatxt.Name = "ortalamatxt";
            this.ortalamatxt.Size = new System.Drawing.Size(173, 22);
            this.ortalamatxt.TabIndex = 17;
            // 
            // avglbl
            // 
            this.avglbl.AutoSize = true;
            this.avglbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.avglbl.Location = new System.Drawing.Point(477, 124);
            this.avglbl.Name = "avglbl";
            this.avglbl.Size = new System.Drawing.Size(107, 25);
            this.avglbl.TabIndex = 16;
            this.avglbl.Text = "Ortalama:";
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button2.Location = new System.Drawing.Point(688, 6);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(78, 30);
            this.button2.TabIndex = 15;
            this.button2.Text = "Çıkış";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // harfnotutxt
            // 
            this.harfnotutxt.Location = new System.Drawing.Point(199, 377);
            this.harfnotutxt.Name = "harfnotutxt";
            this.harfnotutxt.Size = new System.Drawing.Size(200, 22);
            this.harfnotutxt.TabIndex = 14;
            this.harfnotutxt.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS Reference Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(59, 377);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 22);
            this.label1.TabIndex = 13;
            this.label1.Text = "Harf Notu:";
            // 
            // derskodutxt
            // 
            this.derskodutxt.Location = new System.Drawing.Point(199, 175);
            this.derskodutxt.Name = "derskodutxt";
            this.derskodutxt.Size = new System.Drawing.Size(199, 22);
            this.derskodutxt.TabIndex = 12;
            this.derskodutxt.TextChanged += new System.EventHandler(this.derskodutxt_TextChanged);
            // 
            // derskodulbl
            // 
            this.derskodulbl.AutoSize = true;
            this.derskodulbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.derskodulbl.Location = new System.Drawing.Point(58, 171);
            this.derskodulbl.Name = "derskodulbl";
            this.derskodulbl.Size = new System.Drawing.Size(121, 25);
            this.derskodulbl.TabIndex = 11;
            this.derskodulbl.Text = "Ders Kodu:";
            // 
            // notxt
            // 
            this.notxt.Location = new System.Drawing.Point(198, 125);
            this.notxt.Name = "notxt";
            this.notxt.Size = new System.Drawing.Size(201, 22);
            this.notxt.TabIndex = 10;
            this.notxt.TextChanged += new System.EventHandler(this.notxt_TextChanged);
            // 
            // öğrenciid
            // 
            this.öğrenciid.AutoSize = true;
            this.öğrenciid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.öğrenciid.Location = new System.Drawing.Point(58, 124);
            this.öğrenciid.Name = "öğrenciid";
            this.öğrenciid.Size = new System.Drawing.Size(128, 25);
            this.öğrenciid.TabIndex = 9;
            this.öğrenciid.Text = "Öğrenci No:";
            // 
            // kaydetbtn
            // 
            this.kaydetbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.kaydetbtn.Location = new System.Drawing.Point(559, 309);
            this.kaydetbtn.Name = "kaydetbtn";
            this.kaydetbtn.Size = new System.Drawing.Size(173, 80);
            this.kaydetbtn.TabIndex = 8;
            this.kaydetbtn.Text = "Kaydet";
            this.kaydetbtn.UseVisualStyleBackColor = true;
            this.kaydetbtn.Click += new System.EventHandler(this.kaydetbtn_Click);
            this.kaydetbtn.MouseHover += new System.EventHandler(this.kaydetbtn_MouseHover);
            // 
            // büttxt
            // 
            this.büttxt.Location = new System.Drawing.Point(198, 338);
            this.büttxt.Name = "büttxt";
            this.büttxt.Size = new System.Drawing.Size(201, 22);
            this.büttxt.TabIndex = 7;
            this.büttxt.TextChanged += new System.EventHandler(this.büttxt_TextChanged);
            // 
            // finaltxt
            // 
            this.finaltxt.Location = new System.Drawing.Point(198, 280);
            this.finaltxt.Name = "finaltxt";
            this.finaltxt.Size = new System.Drawing.Size(201, 22);
            this.finaltxt.TabIndex = 6;
            this.finaltxt.TextChanged += new System.EventHandler(this.finaltxt_TextChanged);
            // 
            // vizetxt
            // 
            this.vizetxt.Location = new System.Drawing.Point(197, 226);
            this.vizetxt.Name = "vizetxt";
            this.vizetxt.Size = new System.Drawing.Size(202, 22);
            this.vizetxt.TabIndex = 5;
            this.vizetxt.TextChanged += new System.EventHandler(this.vizetxt_TextChanged);
            // 
            // bütünleme
            // 
            this.bütünleme.AutoSize = true;
            this.bütünleme.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.bütünleme.Location = new System.Drawing.Point(58, 334);
            this.bütünleme.Name = "bütünleme";
            this.bütünleme.Size = new System.Drawing.Size(121, 25);
            this.bütünleme.TabIndex = 4;
            this.bütünleme.Text = "Bütünleme:";
            // 
            // finallbl
            // 
            this.finallbl.AutoSize = true;
            this.finallbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.finallbl.Location = new System.Drawing.Point(84, 280);
            this.finallbl.Name = "finallbl";
            this.finallbl.Size = new System.Drawing.Size(66, 25);
            this.finallbl.TabIndex = 3;
            this.finallbl.Text = "Final:";
            // 
            // vizelbl
            // 
            this.vizelbl.AutoSize = true;
            this.vizelbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.vizelbl.Location = new System.Drawing.Point(84, 226);
            this.vizelbl.Name = "vizelbl";
            this.vizelbl.Size = new System.Drawing.Size(62, 25);
            this.vizelbl.TabIndex = 2;
            this.vizelbl.Text = "Vize:";
            // 
            // notlbl
            // 
            this.notlbl.AutoSize = true;
            this.notlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.notlbl.Location = new System.Drawing.Point(238, 18);
            this.notlbl.Name = "notlbl";
            this.notlbl.Size = new System.Drawing.Size(242, 32);
            this.notlbl.TabIndex = 0;
            this.notlbl.Text = "Not Giriş Sistemi";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.MistyRose;
            this.tabPage3.Controls.Add(this.button3);
            this.tabPage3.Controls.Add(this.öğrencinotxt);
            this.tabPage3.Controls.Add(this.chart1);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(783, 402);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Grafik";
            this.tabPage3.Click += new System.EventHandler(this.tabPage3_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button3.Location = new System.Drawing.Point(661, 255);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(103, 34);
            this.button3.TabIndex = 2;
            this.button3.Text = "Göster";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // öğrencinotxt
            // 
            this.öğrencinotxt.Location = new System.Drawing.Point(655, 202);
            this.öğrencinotxt.Name = "öğrencinotxt";
            this.öğrencinotxt.Size = new System.Drawing.Size(109, 22);
            this.öğrencinotxt.TabIndex = 1;
            // 
            // chart1
            // 
            this.chart1.BackColor = System.Drawing.Color.MistyRose;
            chartArea1.AxisX.Title = "Sınıflar";
            chartArea1.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chart1.Legends.Add(legend1);
            this.chart1.Location = new System.Drawing.Point(11, 14);
            this.chart1.Name = "chart1";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "GANO";
            this.chart1.Series.Add(series1);
            this.chart1.Size = new System.Drawing.Size(638, 387);
            this.chart1.TabIndex = 0;
            this.chart1.Text = "chart1";
            title1.Name = "Sınıflar";
            this.chart1.Titles.Add(title1);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.IndianRed;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form2";
            this.Text = "Öğretmen Sistemi";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button görüntülebtn;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label notlbl;
        private System.Windows.Forms.Label bütünleme;
        private System.Windows.Forms.Label finallbl;
        private System.Windows.Forms.Label vizelbl;
        private System.Windows.Forms.TextBox vizetxt;
        private System.Windows.Forms.TextBox notxt;
        private System.Windows.Forms.Label öğrenciid;
        private System.Windows.Forms.Button kaydetbtn;
        private System.Windows.Forms.TextBox büttxt;
        private System.Windows.Forms.TextBox finaltxt;
        private System.Windows.Forms.TextBox derskodutxt;
        private System.Windows.Forms.Label derskodulbl;
        private System.Windows.Forms.TextBox harfnotutxt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label avglbl;
        private System.Windows.Forms.TextBox ortalamatxt;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.TextBox öğrencinotxt;
        private System.Windows.Forms.Button button3;
    }
}