﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Öğretmen
{
    public partial class Form1 : Form
    {
        SqlConnection conn;
        SqlDataReader rd;
        SqlCommand com;
        public Form1()
        {
            InitializeComponent();
        }
        public static string göderilecek_değer;
        private void girişbtn_Click(object sender, EventArgs e)
        {
            
            conn = new SqlConnection("Data Source=DESKTOP-3DNAMQC;Initial Catalog=adonet;Integrated Security=True");
            com = new SqlCommand();
            conn.Open();
            com.Connection = conn;
            com.CommandText = "Select email,password From öğretmen Where email='" + emailtxt.Text + "'And password='" + şifretxt.Text + "' ";
            ; rd = com.ExecuteReader();
            if (rd.Read())
            {
                MessageBox.Show("Giriş Başarılı");
                göderilecek_değer = emailtxt.Text;
                Form2 form2 = new Form2();
                form2.Show();  // form2 göster diyoruz
                this.Hide();
            }
            else
            {
                MessageBox.Show("Hatalı email ve ya şifre");
            }
            conn.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void emailtxt_TextChanged(object sender, EventArgs e)
        {
            emailtxt.ForeColor = Color.DarkBlue;
        }

        private void şifretxt_TextChanged(object sender, EventArgs e)
        {
            şifretxt.ForeColor = Color.DarkBlue;
            şifretxt.PasswordChar = '*';
        }

        private void girişbtn_MouseHover(object sender, EventArgs e)
        {
            girişbtn.BackColor = Color.Black;
            girişbtn.ForeColor = Color.White;
        }
    }
}
