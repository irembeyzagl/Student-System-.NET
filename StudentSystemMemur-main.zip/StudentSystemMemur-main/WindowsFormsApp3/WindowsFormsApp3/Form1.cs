﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        SqlConnection conn;
        SqlDataReader rd;
        SqlCommand com;
        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string user = label2.Text;
            string password = label3.Text;
            conn = new SqlConnection("Data Source=DESKTOP-3DNAMQC;Initial Catalog=adonet;Integrated Security=True");
            com = new SqlCommand();
            conn.Open();
            com.Connection = conn;
            com.CommandText = "Select email,password From memur Where email='" + textBox1.Text + "'And password='" + textBox2.Text + "' ";
            ; rd = com.ExecuteReader();
            if (rd.Read())
            {
                MessageBox.Show("Giriş Başarılı");
                Form2 form2 = new Form2();
                form2.Show();  // form2 göster diyoruz
                this.Hide();


            }
            else
            {
                MessageBox.Show("Hatalı email ve ya şifre");
            }
            conn.Close();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

  
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            textBox1.ForeColor = Color.DarkBlue;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            textBox2.ForeColor = Color.DarkBlue;
            textBox2.PasswordChar = '*';

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_MouseHover(object sender, EventArgs e)
        {
            button1.BackColor = Color.Black;
            button1.ForeColor = Color.White;
            
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            button1.BackColor = Color.White;
            button1.ForeColor = Color.Black;
            button1.BringToFront();
        }
    }
}
